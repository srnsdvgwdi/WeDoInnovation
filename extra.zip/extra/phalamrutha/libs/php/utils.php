<?php
class Utils{
 
 
 function getToken($length=32){
    $token = "";
    $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
    $codeAlphabet.= "0123456789";
    for($i=0;$i<$length;$i++){
        $token .= $codeAlphabet[$this->crypto_rand_secure(0,strlen($codeAlphabet))];
    }
    return $token;
}
 
function crypto_rand_secure($min, $max) {
    $range = $max - $min;
    if ($range < 0) return $min; // not so random...
    $log = log($range, 2);
    $bytes = (int) ($log / 8) + 1; // length in bytes
    $bits = (int) $log + 1; // length in bits
    $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
    do {
        $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
        $rnd = $rnd & $filter; // discard irrelevant bits
    } while ($rnd >= $range);
    return $min + $rnd;
}

// send email using built in php mailer
public function sendEmailViaPhpMail($send_to_email, $subject, $body){
 
    $from_name="Your Name";
    $from_email="yourname@yourdomain.com";
 
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
    $headers .= "From: {$from_name} <{$from_email}> \n";
 
    if(mail($send_to_email, $subject, $body, $headers)){
        return true;
    }
 
    return false;
}


// check if given access_code exist in the database
function accessCodeExists(){
 
    // query to check if access_code exists
    $query = "SELECT id
            FROM " . $this->table_name . "
            WHERE access_code = ?
            LIMIT 0,1";
 
    // prepare the query
    $stmt = $this->conn->prepare( $query );
 
    // sanitize
    $this->access_code=htmlspecialchars(strip_tags($this->access_code));
 
    // bind given access_code value
    $stmt->bindParam(1, $this->access_code);
 
    // execute the query
    $stmt->execute();
 
    // get number of rows
    $num = $stmt->rowCount();
 
    // if access_code exists
    if($num>0){
 
        // return true because access_code exists in the database
        return true;
    }
 
    // return false if access_code does not exist in the database
    return false;
 
}

// used in email verification feature
function updateStatusByAccessCode(){
 
    // update query
    $query = "UPDATE " . $this->table_name . "
            SET status = :status
            WHERE access_code = :access_code";
 
    // prepare the query
    $stmt = $this->conn->prepare($query);
 
    // sanitize
    $this->status=htmlspecialchars(strip_tags($this->status));
    $this->access_code=htmlspecialchars(strip_tags($this->access_code));
 
    // bind the values from the form
    $stmt->bindParam(':status', $this->status);
    $stmt->bindParam(':access_code', $this->access_code);
 
    // execute the query
    if($stmt->execute()){
        return true;
    }
 
    return false;
}


}
?>