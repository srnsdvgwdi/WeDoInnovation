<?php
// 'user' object
class User{
 
    // database connection and table name
    private $conn;
    private $table_utype= "usera_type";
	private $table_ud = "user_details";
	private $table_ul = "user_login";
 
    // object properties
    public $USERID;
    public $FNAME;
    public $LNAME;
    public $ADDRESS;
    public $PHONE;
    public $USERNAME;
    public $PASSWORD;
    public $LAST_LOGIN;
    public $UTYPENAME;
   
    // constructor
    public function __construct($db)
	{
        $this->conn = $db;
    }
	
	// check if given email exist in the database
	function emailExists()
	{
		// query to check if email exists
		$query = "SELECT USERID, FNAME, LNAME, password
            FROM " . $this->table_utype , $this->table_ud, $this->table_ul . "
            WHERE username = ? 
            LIMIT 0,1";
 
    // prepare the query
    $stmt = $this->conn->prepare( $query );
 
    // sanitize
    $this->email=htmlspecialchars(strip_tags($this->USERNAME));
 
    // bind given email value
    $stmt->bindParam(1, $this->USERNAME);
 
    // execute the query
    $stmt->execute();
 
    // get number of rows
    $num = $stmt->rowCount();
 
    // if email exists, assign values to object properties for easy access and use for php sessions
    if($num>0){
 
        // get record details / values
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
        // assign values to object properties
        $this->id = $row['id'];
        $this->firstname = $row['firstname'];
        $this->lastname = $row['lastname'];
        $this->access_level = $row['access_level'];
        $this->password = $row['password'];
        $this->status = $row['status'];
 
        // return true because email exists in the database
        return true;
    }
 
    // return false if email does not exist in the database
    return false;
}
	
	
	
}