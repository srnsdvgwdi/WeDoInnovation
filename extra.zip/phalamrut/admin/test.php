<html>  
    <head>  
    <title>Dynamic Drop Down List</title>  
    </head>  
    <BODY bgcolor ="pink">  
        <form id="form1" name="form1" method="post" action="<?php echo $PHP_SELF; ?>">  
            Employee List :  
            <select Emp Name='NEW'>  
            <option value="">--- Select ---</option>  
            <?  
                mysql_connect ("localhost","root","password");  
                mysql_select_db ("main_categoty");  
                $select="company";  
                if (isset ($select)&&$select!=""){  
                $select=$_POST ['NEW'];  
            }  
            ?>  
            <?  
                $list=mysql_query("select * from main_categoty");  
            while($row_list=mysql_fetch_assoc($list)){  
                ?>  
                    <option value="'<? echo $row_list['CATEGORY_NAME']; ?>'" <? if($row_list['CATEGORY_NAME']==$select){ echo "selected"; } ?>>  
                                         <?echo $row_list['CATEGORY_NAME'];?>  
                    </option>  
                <?  
                }  
                ?>  
            </select>  
            <input type="submit" name="Submit" value="Select" />  
        </form>  
    </body>  
</html>  


while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<option value=".$row['CATEGORY_ID'].">".$row['CATEGORY_ID']."</option>";
        }

<?php  
						
						
					// echo "<p>{$subcategorylist->CATEGORY_NAME}</p>";
					 $stmt=$subcategorylist->getMainCategoryName();
					 $num=$stmt->rowcount();
					 echo "<p>$num</p>";
					 $data=$stmt->fetch(PDO::FETCH_ASSOC);
					 ?>
					 <?php foreach ($data as $row): ?>
						<option><?=$row['CATEGORY_NAME']?></option>
						<?php endforeach ?>

while($row=$stmt->fetch(PDO::FETCH_ASSOC))
					  { 
						//extract($row);	
						//$listnew[]=$row;
							//echo "<p>{$CATEGORY_NAME}</p>";
						 echo "<option value='' >".$row['CATEGORY_NAME']."</option>";
						 //echo "<p>$row['CATEGORY_NAME']</p>";
						 print $row['CATEGORY_NAME'].'<br>';
							

					  }




//$db=mysqli_connect("localhost","root"."password","phalamruthas")or die ("could not connect to mysql");
						//$subjectName = "SELECT * FROM main_categoty value";
					
					//$subject = mysqli_query($subjectName, $db );	
					
					//$subject=mysqli_query($db, $subjectName) or die(mysqli_error($db));





					  while($row=$stmt->fetch(PDO::FETCH_ASSOC))
					  { 
						
						
						
						
						
						 extract($row);	
						//$listnew[]=$row;
							echo "<p>{$CATEGORY_NAME}</p>";
							
							echo "<option > {$CATEGORY_NAME} </option>";

					  }
					 
					 ?>