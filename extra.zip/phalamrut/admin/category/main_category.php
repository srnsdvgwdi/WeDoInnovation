<?php
	// core configuration
	include_once "../config/core.php";
	$page_title = "Main Category";
	//Inculde the DB
	include_once "../config/database.php";
	// check if logged in as admin
	//include_once "login_checker.php";
	include_once "../objects/categorylist.php";
	
	// include page header HTML
	include_once 'layout_head.php'; 
	echo "<div class='col-md-12'>";
			// get database connection
		$database = new Database();
		$db = $database->getConnection();
		$categorylist = new Categorylist($db);
		//$utils = new Utils();
	
	if($_POST)
	{

		// set user email to detect if it already exists
		// $user->email=$_POST['email'];
		echo "<p> $categorylist->CATEGORY_NAME </p>";
		$categorylist->CATEGORY_NAME=$_POST['CATEGORY_NAME'];
		$categorylist->cat_img=$_FILES['cat_img'];
		$categorylist->category_desc=$_POST['category_desc'];
		if($categorylist->createCategory())
		{
		 
		 echo "<div class='alert alert-danger'>
					Category Created sucessfully!!
				</div>";
		
		}
		else
		{
				echo "<div class='alert alert-danger'>
					Alredy Exited
				</div>";
		}
	}
	else
	{
		

	}	
			
		 
	
	
?>


<form enctype="multipart/form-data" action='main_category.php' method='post' id='category'>
 
    <table class='table table-responsive'>
		<tr>
            <td class='width-30-percent'>Enter The Product Name</td>
            <td><input type='text' name='CATEGORY_NAME' class='form-control'  required value="<?php echo isset($_POST['CATEGORY_NAME']) ? htmlspecialchars($_POST['CATEGORY_NAME'], ENT_QUOTES) : "";  ?>" /></td>
        </tr>
		<tr>
            <td class='width-30-percent'>Select Image</td>
            <td><input class="input-group" type="file" name="cat_img" accept="phala/images/*" /> </td>
        </tr>
		<tr>
            <td class='width-30-percent'>Enter Description</td>
            <td><input type='text' name='category_desc' class='form-control'  required value="<?php echo isset($_POST['category_desc']) ? htmlspecialchars($_POST['category_desc'], ENT_QUOTES) : "";  ?>" /></td>
        </tr>
		
		<tr>
            <td></td>
            <td>
                <button type="submit" class="btn btn-primary">
                    <span class="glyphicon glyphicon-plus"></span> Create
                </button>
            </td>
        </tr>
		
 	</table>
</form>

<?php
include_once "../admin/read_category.php";
echo "</div>";
 
// include page footer HTML
include_once "layout_foot.php";
?>