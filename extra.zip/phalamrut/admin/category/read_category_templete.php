<?php
	
	if(isset($_POST['Delete'])) { 
            echo "This is Button1 that is selected"; 
        } 
        if(isset($_POST['button2'])) { 
            echo "This is Button2 that is selected"; 
        }
	
	// display the table if the number of users retrieved was greater than zero
	if($num>0)
	{
		echo "<table class='table table-hover table-responsive table-bordered'>";
		// table headers
		echo "<tr>";
        echo "<th class='text-center'>SL NO</th>";
        echo "<th class='text-center'>CATEGORY NAME</th>";
		//echo "<th class='text-center'>ACTION</th>";
		echo "</tr>";
 
    // loop through the user records
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
		{
			extract($row);
 			// display category details
				echo "<tr>";
				echo "<td align='center'>{$CATEGORY_ID}</td>";
				echo "<td align='center'>{$CATEGORY_NAME}</td>";
				//echo "<td> <form method='POST' action='?delete=delete&id=##'><input class='btn btn-primary' type='submit' name='delete' value='delete'></form></td>";
				echo "</tr>";
		
        }
		echo "</table>";
		$page_url="read_cateogory.php?";
		$total_rows = $categorylist->countAll();
		// actual paging buttons
		include_once 'paging.php';
		
		
		
	}
 
	// tell the user there are no selfies
	else
	{
		echo "<div class='alert alert-danger'>
        <strong>No users found.</strong>
		</div>";
	}
?>