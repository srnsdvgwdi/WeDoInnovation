<?php
	// core configuration
	include_once "../config/core.php";
	$page_title = "Sub Category";
	//Inculde the DB
	include_once "../config/database.php";
	// check if logged in as admin
	//include_once "login_checker.php";
	include_once "../objects/subcategorylist.php";
	
	// include page header HTML
	include_once 'layout_head.php'; 
	echo "<div class='col-md-12'>";
	// get database connection
	$database = new Database();
	$db = $database->getConnection();
	$subcategorylist = new Subcategorylist($db);
	
	//$utils = new Utils();
	//$subcategorylist->SUBCATEGORY_NAME=$_POST['SUBCATEGORY_NAME'];
	//$subcategorylist->CATEGORY_NAMES=$_POST['CATEGORY_NAMES'];
	
	
	//$stmt=$subcategorylist->getMainCategoryName();
	//$num=$stmt->rowcount();
	//echo "<p>$num</p>";
	//$data=$stmt->fetch(PDO::FETCH_ASSOC);
	//echo "<p>$data</p>";
	
	//$result=$stmt->fetchAll(PDO::FETCH_NUM);

	//print_r($result);
	
	//foreach($result as $row)
	//{
		//printf("$row[0] $row[1]");
	//}
	//echo "<p>$result[1].PHP_EOL</p>";
	
	
	
		
	
	if($_POST)
	{
		// set user email to detect if it already exists
		// $user->email=$_POST['email'];
		echo "<p> $subcategorylist->SUBCATEGORY_NAME </p>";
		$subcategorylist->SUBCATEGORY_NAME=$_POST['SUBCATEGORY_NAME'];
		$subcategorylist->CATEGORY_NAMES=$_POST['CATEGORY_NAMES'];
		if($subcategorylist->createSubCategory())
		{
			echo "<div class='alert alert-danger'>
					Category Created sucessfully!!
				</div>";
		}
		else
		{
				echo "<div class='alert alert-danger'>
					Alredy Exited
				</div>";
		}
	}
	else
	{
		

	}	
	
	
					
		/*  $stmt=$subcategorylist->getMainCategoryName();
		$num=$stmt->rowcount();
		printf("count:::$num");
		$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
		foreach ($result as $row)
		{
			//print $row->CATEGORY_NAME;
			//extract($row);
			//printf("$row->CATEGORY_NAME");
			print_r($row['CATEGORY_NAME'].PHP_EOL);
			//printf("\n");
			
		} */ 
		
?>


<form action='sub_category.php' method='post' id='category' action="<?php echo $PHP_SELF; ?>" >
    <table class='table table-responsive'>
		<tr>
			<td class='width-30-percent'>Select the Main Category</td>
			
			<td> <select name="CATEGORY_NAMES" id="sclient" class="form-control"> 
			<?php $stmt=$subcategorylist->getMainCategoryName();
		$num=$stmt->rowcount();
		$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
		
		foreach ($result as $row)
		{
		
			$value = $row['CATEGORY_NAME'];
		
			?>
			
			<option value="<?php echo $value; ?>"><?php echo $value; ?></option>;
			<?php 
			
		} 
		
		
		?>
		
		
				 <option value="">Select Category</option>
					
							
							
					
				</select>
			</td>
		</tr>
		<tr>
            <td class='width-30-percent'>Enter The Subcategory Name</td>
            <td><input type='text' name='SUBCATEGORY_NAME' class='form-control'  required value="<?php echo isset($_POST['SUBCATEGORY_NAME']) ? htmlspecialchars($_POST['SUBCATEGORY_NAME'], ENT_QUOTES) : "";  ?>" /></td>
        </tr>
		
		<tr>
            <td></td>
            <td>
                <button type="submit" class="btn btn-primary">
                    <span class="glyphicon glyphicon-plus"></span> Create
                </button>
            </td>
        </tr>
	</table>
</form>

<?php
	include_once "../admin/read_sub_category.php";
	echo "</div>";
	// include page footer HTML
	include_once "layout_foot.php";
?>