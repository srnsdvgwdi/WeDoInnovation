<?php
// core configuration
include_once "../config/core.php";
 
// check if logged in as admin
include_once "login_checker.php";
 
// include classes
include_once '../config/database.php';
include_once '../objects/subcategorylist.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// initialize objects
$subcategorylist = new SubCategorylist($db);
 
// set page title
$page_title = "SubCategorylist";
 
// include page header HTML
include_once "layout_head.php";
 
echo "<div class='col-md-12'>";
 
    // read all users from the database
    $stmt = $subcategorylist->readAllSubCategory($from_record_num, $records_per_page);
 
    // count retrieved users
    $num = $stmt->rowCount();
	echo "<p>$num</p>";
    // to identify page for paging
    $page_url="read_sub_category.php?";
 
    // include products table HTML template
    include_once "read_sub_category_templete.php";
 
echo "</div>";
 
// include page footer HTML
include_once "layout_foot.php";
?>