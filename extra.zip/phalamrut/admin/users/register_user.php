<!--
Page for the rgister the cutomer
-->

<?php
	// core configuration	
	include_once "../../config/core.php";
	
	$page_title = "Register";
 
	// include login checker
	//include_once 'login_checker.php';
	// include classes
	include_once "../../config/database.php";
	include_once "../../objects/user.php";
	include_once "../../libs/php/utils.php";
 
	// include page header HTML
	include_once '../layout_head.php'; 
	echo "<div class='col-md-12'>"; 
	
	// initialize objects
	// registration form HTML will be here
	// code when form was submitted will be here	
	// if form was posted
	if($_POST)
	{
		$database = new Database();
		$db = $database->getConnection();
		$user = new User($db);
		$utils = new Utils();
		$ids=$user->getUserTypeId("Admin");
		$ids = $ids->fetchAll(PDO::FETCH_ASSOC);
		foreach ($ids as $row)
		{
			$value=$row['UTYPEID'];
			echo "<p>$value</p>";
						
		}

		$user = new User($db);
		$utils = new Utils();
	   // $user->email=$_POST['email'];
		echo "<p> $user->email </p>";
		if(isset($_POST['userType']))
		{
			echo "<span>You have selected :<b> ".$_POST['userType']."</b></span>";
			//$user->access_level=$_POST['userType'];
			$usertypeid=$user->getUserTypeId($_POST['userType']);
			$res=$usertypeid->fetchAll(PDO::FETCH_ASSOC);
			foreach($res as $row)
			{
				$value=$row['UTYPEID'];
				echo "<p>$value</p>";
				$user->UTYPEID=$value;
							
			}
		}
		else
		{ 
			echo "<span>Please choose any radio button.</span>";
		}
		
		$user->FNAME=$_POST['FNAME'];
		$user->LANEM=$_POST['LNAME'];
		$user->ADDRESS=$_POST['ADDRESS'];
		$user->ADDRESS=$_POST['ADDRESS'];
		$user->PHONE=$_POST['PHONE'];
		$user->EMAIL=$_POST['EMAIL'];
		$user->UNAME=$_POST['UNAME'];
		$user->PASSWORD=$_POST['PASSWORD'];
		
		
		//$user->UTYPEID=$usertypeid;
		//echo "<p>$usertypeid</p>";
		$userdetailsid=$user->getUserDetailsTypeId($_POST['FNAME']);
		$id = $userdetailsid->fetchAll(PDO::FETCH_ASSOC);
		foreach($userdetailsid as $row)
		{
			$value2=$row['USERID'];
			echo "<p>$value2</p>";
						
		}
		//$user->USERID=$userdetailsid;
		//echo "<p>$userdetailsid</p>";
		
		/* $user->firstname=$_POST['firstname'];
		$user->lastname=$_POST['lastname'];
		$user->contact_number=$_POST['contact_number'];
		$user->address=$_POST['address'];
		$user->email=$_POST['email'];
		$user->password=$_POST['password'];
		$user->status=0;
		// access code for email verification
		$access_code=$utils->getToken();
		$user->access_code=$access_code; */
		
		// get database connection
		$database = new Database();
		$db = $database->getConnection();
		
		
		// create the user
		if($user->create())
		{
			// send confimation email
			$send_to_email=$_POST['email'];
			$body="Hi {$send_to_email}.<br /><br />";
			$body.="Please click the following link to verify your email and login: {$home_url}verify/?access_code={$access_code}";
			$subject="Verification Email";
			if($utils->sendEmailViaPhpMail($send_to_email, $subject, $body))
			{
				echo "<div class='alert alert-success'>
				Verification link was sent to your email. Click that link to login.
				</div>";
			}
			else
			{
				echo "<div class='alert alert-danger'>
				User was created but unable to send verification email. Please contact admin.
				</div>";
			}
			// empty posted values
			$_POST=array();
		}
		else
		{
			echo "<div class='alert alert-danger' role='alert'>Unable to register. Please try again.</div>";
		}
	}
?>


<form action='register_user.php' method='post' id='register'>
 
    <table class='table table-responsive'>
 
        <tr>
            <td class='width-30-percent'>Firstname</td>
            <td><input type='text' name='FNAME' class='form-control' required value="<?php echo isset($_POST['FNAME']) ? htmlspecialchars($_POST['FNAME'], ENT_QUOTES) : "";  ?>" /></td>
        </tr>
 
        <tr>
            <td>Lastname</td>
            <td><input type='text' name='LNAME' class='form-control' required value="<?php echo isset($_POST['LNAME']) ? htmlspecialchars($_POST['LNAME'], ENT_QUOTES) : "";  ?>" /></td>
        </tr>
 
        <tr>
            <td>Contact Number</td>
            <td><input type='text' name='PHONE' class='form-control' required value="<?php echo isset($_POST['PHONE']) ? htmlspecialchars($_POST['PHONE'], ENT_QUOTES) : "";  ?>" /></td>
        </tr>
 
        <tr>
            <td>Address</td>
            <td><textarea name='ADDRESS' class='form-control' required><?php echo isset($_POST['ADDRESS']) ? htmlspecialchars($_POST['ADDRESS'], ENT_QUOTES) : "";  ?></textarea></td>
        </tr>
 
        <tr>
            <td>Email</td>
            <td><input type='email' name='EMAIL' class='form-control' required value="<?php echo isset($_POST['EMAIL']) ? htmlspecialchars($_POST['EMAIL'], ENT_QUOTES) : "";  ?>" /></td>
        </tr>
		<tr>
            <td>User Name</td>
            <td><input type='email' name='UNAME' class='form-control' required value="<?php echo isset($_POST['UNAME']) ? htmlspecialchars($_POST['UNAME'], ENT_QUOTES) : "";  ?>" /></td>
        </tr>
        <tr>
            <td>Password</td>
            <td><input type='password' name='PASSWORD' class='form-control' required id='passwordInput'></td>
        </tr>
		
		<tr>
            <td>Select User Ttype</td>
            <td> <input type="radio"  name="userType" id="customer" value="Cutomer"  ><span>Customer</span>
				 <input type="radio"  name="userType" id="admin" value="Admin"  > <span>Admin</span>
				  
			</td>
			

        </tr>
		 
        <tr>
            <td></td>
            <td>
                <button type="submit" class="btn btn-primary">
                    <span class="glyphicon glyphicon-plus"></span> Register
                </button>
            </td>
        </tr>
 
    </table>
</form>
<?php
 
// include page footer HTML
include_once "../layout_foot.php";
?>