<?php
// 'user' object
class User
{
 
    // database connection and table name
    private $conn;
    private $table_name = "users";
	private $usertype_table = "USERTYPE";
	private $userdetails_table = "USER_DETAILS";
	private $logindetails_table = "LOGIN_DETAILS";
 
    // object properties
    public $id;
    public $firstname;
    public $lastname;
    public $email;
    public $contact_number;
    public $address;
    public $password;
    public $access_level;
	public $access_code;
    public $usertype;
    public $status;
    public $created;
    public $modified;
	    
    public $FNAME;
    public $LNAME;
    public $EMAIL;
    public $PHONE;
    public $ADDRESS;
    public $PASSWORD;
   
    public $USERTYPE;
    public $UTYPEID;
    public $CREATEDDATE;
    public $MODIFIEDDATE;
    public $LASTLOGIN;
	public $USERID;
	
	
    // constructor
    public function __construct($db)
	{
        $this->conn = $db;
    }
	
	
	//Get mail user type
	function getUserTypeId($usertypeid)
	{
		$query="SELECT UTYPEID FROM".$this->usertype_table."WHERE USERTYPE = '".$usertypeid."' ORDER BY LIMIT 0,1";
		$stmt = $this->conn->prepare($query);
		$this->UTYPEID=htmlspecialchars(strip_tags($this->UTYPEID));
		$stmt->bindParam(1, $this->UTYPEID);
		$stmt->execute();
		return $stmt;
	}
	
	//Get userid  from user details
	function getUserDetailsTypeId($usertypeid)
	{
		$query="SELECT USERID FROM".$this->userdetails_table."WHERE FNAME ='".$usertypeid."' ORDER BY LIMIT 0,1";
		$stmt = $this->conn->prepare($query);
		$this->USERID=htmlspecialchars(strip_tags($this->USERID));
		$stmt->bindParam(1, $this->USERID);
		$stmt->execute();
		return $stmt;
	}
	
	
	// create new user record
	function create()
	{
		
		// to get time stamp for 'created' field
		$this->created=date('Y-m-d H:i:s');
		$this->LASTLOGIN=date('Y-m-d H:i:s');
		
		// insert query
		$query = "INSERT INTO " . $this->userdetails_table . "
            SET
			UTYPEID = :UTYPEID,
			FNAME = :FNAME,
			LANEM = :LNAME,
			EMAIL = :EMAIL,
			PHONE = :PHONE,
			ADDRESS = :ADDRESS,
			CREATEDDATE = :created,
			ISDELETED = 0";
			
			
		
		
		// prepare the query
		$stmt = $this->conn->prepare($query);
		
		
		// sanitize
		$this->UTYPEID=htmlspecialchars(strip_tags($this->UTYPEID));
		$this->FNAME=htmlspecialchars(strip_tags($this->FNAME));
		$this->LNAME=htmlspecialchars(strip_tags($this->LNAME));
		$this->EMAIL=htmlspecialchars(strip_tags($this->EMAIL));
		$this->PHONE=htmlspecialchars(strip_tags($this->PHONE));
		$this->ADDRESS=htmlspecialchars(strip_tags($this->ADDRESS));
		$this->CREATEDDATE=htmlspecialchars(strip_tags($this->CREATEDDATE));
		$this->MODIFIEDDATE=htmlspecialchars(strip_tags($this->MODIFIEDDATE));
		$this->UNAME=htmlspecialchars(strip_tags($this->UNAME));
		$this->PASSWORD=htmlspecialchars(strip_tags($this->PASSWORD));
		$this->UTYPEID=htmlspecialchars(strip_tags($this->UTYPEID));
		$this->USERID=htmlspecialchars(strip_tags($this->USERID));
 
		// bind the values
		$stmt->bindParam(':FNAME', $this->FNAME);
		$stmt->bindParam(':LNAME', $this->LNAME);
		$stmt->bindParam(':EMAIL', $this->EMAIL);
		$stmt->bindParam(':PHONE', $this->PHONE);
		$stmt->bindParam(':ADDRESS', $this->ADDRESS);
		
	 	// hash the password before saving to database
		$password_hash = password_hash($this->PASSWORD, PASSWORD_BCRYPT);
		//$stmt2->bindParam(':PASSWORD', $password_hash);
		//$stmt2->bindParam(':UTYPEID', $this->UTYPEID);
		$stmt->bindParam(':USERID', $this->USERID);
		$stmt->bindParam(':CREATEDDATE', $this->CREATEDDATE);
		$stmt->bindParam(':MODIFIEDDATE', $this->MODIFIEDDATE);
		//$stmt2->bindParam(':UNAME', $this->UNAME);
		//$stmt2->bindParam(':PASSWORD', $this->PASSWORD);
		//$stmt->bindParam(':access_level', $this->access_level);
		//$stmt->bindParam(':access_code', $this->access_code);
		//$stmt->bindParam(':status', $this->status);
		//$stmt->bindParam(':created', $this->created);
 
		/* // sanitize
		$this->firstname=htmlspecialchars(strip_tags($this->firstname));
		$this->lastname=htmlspecialchars(strip_tags($this->lastname));
		$this->email=htmlspecialchars(strip_tags($this->email));
		$this->contact_number=htmlspecialchars(strip_tags($this->contact_number));
		$this->address=htmlspecialchars(strip_tags($this->address));
		$this->password=htmlspecialchars(strip_tags($this->password));
		$this->access_level=htmlspecialchars(strip_tags($this->access_level));
		$this->access_code=htmlspecialchars(strip_tags($this->access_code));
		$this->status=htmlspecialchars(strip_tags($this->status));
 
		// bind the values
		$stmt->bindParam(':firstname', $this->firstname);
		$stmt->bindParam(':lastname', $this->lastname);
		$stmt->bindParam(':email', $this->email);
		$stmt->bindParam(':contact_number', $this->contact_number);
		$stmt->bindParam(':address', $this->address);
	 
		// hash the password before saving to database
		$password_hash = password_hash($this->password, PASSWORD_BCRYPT);
		$stmt->bindParam(':password', $password_hash);
	 
		$stmt->bindParam(':access_level', $this->access_level);
		$stmt->bindParam(':access_code', $this->access_code);
		$stmt->bindParam(':status', $this->status);
		$stmt->bindParam(':created', $this->created); */
 
		// execute the query, also check if query was successful
		if($stmt->execute())
		{
			//insert query
			$query2 = "INSERT INTO " . $this->logindetails_table . "
             SET
			 USERID = :USERID,
			 UTYPEID = :UTYPEID,
			 UNAME = :UNAME,
			 PASSWORD=:PASSWORD,
			 LASTLOGIN = :LASTLOGIN"; 
			$stmt2 = $this->conn->prepare($query2);
			return true;
		}
		else
		{
			$this->showError($stmt);
			return false;
		}
	}
	
	// create new user record
	// read all user records
	function readAll($from_record_num, $records_per_page)
	{
		// query to read all user records, with limit clause for pagination
		$query = "SELECT
                id,
                firstname,
                lastname,
                email,
                contact_number,
                access_level,
                created
            FROM " . $this->table_name . "
            ORDER BY id DESC
            LIMIT ?, ?";
 
		// prepare query statement
		$stmt = $this->conn->prepare( $query );
		// bind limit clause variables
		$stmt->bindParam(1, $from_record_num, PDO::PARAM_INT);
		$stmt->bindParam(2, $records_per_page, PDO::PARAM_INT);
 
		// execute query
		$stmt->execute();
		// return values
		return $stmt;
	}
	// used for paging users
	public function countAll()
	{
 
		// query to select all user records
		$query = "SELECT id FROM " . $this->table_name . "";
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		// execute query
		$stmt->execute();
		// get number of rows
		$num = $stmt->rowCount();
		// return row count
		return $num;
	}
	// check if given access_code exist in the database
	function accessCodeExists()
	{
		// query to check if access_code exists
		$query = "SELECT id
            FROM " . $this->table_name . "
            WHERE access_code = ?
            LIMIT 0,1";
		// prepare the query
		$stmt = $this->conn->prepare( $query );
		// sanitize
		$this->access_code=htmlspecialchars(strip_tags($this->access_code));
		// bind given access_code value
		$stmt->bindParam(1, $this->access_code);
		// execute the query
		$stmt->execute();
		// get number of rows
		$num = $stmt->rowCount();
		// if access_code exists
		if($num>0)
		{
 			// return true because access_code exists in the database
			return true;
		}
 		// return false if access_code does not exist in the database
		return false;
 	}


// used in email verification feature
function updateStatusByAccessCode(){
 
    // update query
    $query = "UPDATE " . $this->table_name . "
            SET status = :status
            WHERE access_code = :access_code";
 
    // prepare the query
    $stmt = $this->conn->prepare($query);
 
    // sanitize
    $this->status=htmlspecialchars(strip_tags($this->status));
    $this->access_code=htmlspecialchars(strip_tags($this->access_code));
 
    // bind the values from the form
    $stmt->bindParam(':status', $this->status);
    $stmt->bindParam(':access_code', $this->access_code);
 
    // execute the query
    if($stmt->execute()){
        return true;
    }
 
    return false;
}

// used in forgot password feature
function updateAccessCode(){
 
    // update query
    $query = "UPDATE
                " . $this->table_name . "
            SET
                access_code = :access_code
            WHERE
                email = :email";
 
    // prepare the query
    $stmt = $this->conn->prepare($query);
 
    // sanitize
    $this->access_code=htmlspecialchars(strip_tags($this->access_code));
    $this->email=htmlspecialchars(strip_tags($this->email));
 
    // bind the values from the form
    $stmt->bindParam(':access_code', $this->access_code);
    $stmt->bindParam(':email', $this->email);
 
    // execute the query
    if($stmt->execute()){
        return true;
    }
 
    return false;
}


// used in forgot password feature
function updatePassword(){
 
    // update query
    $query = "UPDATE " . $this->table_name . "
            SET password = :password
            WHERE access_code = :access_code";
 
    // prepare the query
    $stmt = $this->conn->prepare($query);
 
    // sanitize
    $this->password=htmlspecialchars(strip_tags($this->password));
    $this->access_code=htmlspecialchars(strip_tags($this->access_code));
 
    // bind the values from the form
    $password_hash = password_hash($this->password, PASSWORD_BCRYPT);
    $stmt->bindParam(':password', $password_hash);
    $stmt->bindParam(':access_code', $this->access_code);
 
    // execute the query
    if($stmt->execute()){
        return true;
    }
 
    return false;
}	
	
	
	// check if given email exist in the database
function emailExists(){
 
    // query to check if email exists
    $query = "SELECT id, firstname, lastname, access_level, password, status
            FROM " . $this->table_name . "
            WHERE email = ?
            LIMIT 0,1";
 
    // prepare the query
    $stmt = $this->conn->prepare($query);
 
    // sanitize
    $this->email=htmlspecialchars(strip_tags($this->email));
 
    // bind given email value
    $stmt->bindParam(1, $this->email);
 
    // execute the query
    $stmt->execute();
 
    // get number of rows
    $num = $stmt->rowCount();
 
    // if email exists, assign values to object properties for easy access and use for php sessions
    if($num>0){
 
        // get record details / values
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
        // assign values to object properties
        $this->id = $row['id'];
        $this->firstname = $row['firstname'];
        $this->lastname = $row['lastname'];
        $this->access_level = $row['access_level'];
        $this->password = $row['password'];
        $this->status = $row['status'];
 
        // return true because email exists in the database
        return true;
    }
 
    // return false if email does not exist in the database
    return false;
} 
}



