<?php

class Categorylist
{
		// database connection and table name
    private $conn;
    private $table_name = "main_categoty";
	
	// object properties
	public $CATEGORY_ID;
	public $CATEGORY_NAME;
	public $CREATEDDATE;
    public $MODIFIED_DATE;
	public $cat_img;
	public $category_desc;	
	// constructor
    public function __construct($db)
	{
        $this->conn = $db;
    }
	
	// create new category record
	function createCategory()
	{
 
		// to get time stamp for 'created' field
		$this->CREATEDDATE=date('Y-m-d H:i:s');
		
		//this->category_id="mc_"+$i;
		
			
		
		$imgFile = $_FILES['cat_img']['name'];
		$tmp_dir = $_FILES['cat_img']['tmp_name'];
		$imgSize = $_FILES['cat_img']['size'];
		
		//To upload to the dir
		$upload_dir = 'phala/images/'; 
		// get image extension
		$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); 
		// valid image extensions
		$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
		// rename uploading image
		$cat_img = rand(1000,1000000).".".$imgExt;
	 	// allow valid image file formats
		   if(in_array($imgExt, $valid_extensions))
		   {   
				// Check file size '5MB'
				if($imgSize < 5000000)    
				{
					move_uploaded_file($tmp_dir,$upload_dir.$cat_img);
				}
				else
				{
					$errMSG = "Sorry, your file is too large.";
				}
		   }
		   else
		   {
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";  
		   }
		   
		   	// insert query
		$query = "INSERT INTO " . $this->table_name . "
            SET
			CATEGORY_NAME = :CATEGORY_NAME,
			cat_img = :cat_img
			category_desc=:category_desc,
			CREATEDDATE = :CREATEDDATE";
 		// prepare the query
		$stmt = $this->conn->prepare($query);
		
		$this->CATEGORY_NAME=htmlspecialchars(strip_tags($this->CATEGORY_NAME));
		$this->category_desc=htmlspecialchars(strip_tags($this->category_desc));
		//$this->cat_img=htmlspecialchars(strip_tags($this->cat_img));
		
		
		$stmt->bindParam(':CATEGORY_NAME', $this->CATEGORY_NAME);
		$stmt->bindParam(':cat_img', $this->cat_img);
		$stmt->bindParam(':category_desc', $this->category_desc);
		$stmt->bindParam(':CREATEDDATE', $this->CREATEDDATE);
			 	
		
		if($stmt->execute())
		{
			return true;
		}
		else
		{
			$this->showError($stmt);
			return false;
		}
	}
	
	// used for paging users
	public function countAll()
	{
 
		// query to select all user records
		$query = "SELECT CATEGORY_ID FROM " . $this->table_name . "";
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		// execute query
		$stmt->execute();
		// get number of rows
		$num = $stmt->rowCount();
		// return row count
		return $num;
	}
	
		// read all user records
	function readAllCategory($from_record_num, $records_per_page)
	{
		// query to read all user records, with limit clause for pagination
		$query = "SELECT
                CATEGORY_ID,
				CATEGORY_NAME
            FROM " . $this->table_name . "
            ORDER BY CATEGORY_ID DESC
            LIMIT ?, ?";
 
		// prepare query statement
		$stmt = $this->conn->prepare( $query );
		// bind limit clause variables
		$stmt->bindParam(1, $from_record_num, PDO::PARAM_INT);
		$stmt->bindParam(2, $records_per_page, PDO::PARAM_INT);
 
		// execute query
		$stmt->execute();
		// return values
		return $stmt;
	}
}
	

?>