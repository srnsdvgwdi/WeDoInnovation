<?php

class Subcategorylist
{
		// database connection and table name
    private $conn;
    private $table_name = "sub_category";
	private $table_name2 = "main_categoty";
	// object properties
	public $SUBCATEGORY_ID;
	public $CATEGORY_ID;
	public $CATEGORY_NAME;
	//public $CATEGORY_NAMES;

	public $SUBCATEGORY_NAME;
	public $CREATEDDATE;
    public $MODIFIED_DATE;
	public $i = 10;
	
	
	// constructor
    public function __construct($db)
	{
        $this->conn = $db;
    }
	
	function getMainCategoryId($CATEGORY_NAME)
	{
		
		echo "<p>Inside craetw getMainCategoryId() $CATEGORY_NAME</p>";
				// insert query
		$query = "SELECT CATEGORY_ID FROM " . $this->table_name2 . "WHERE CATEGORY_NAME= '".$CATEGORY_NAME."'";
        $stmt = $this->conn->prepare($query); 
		$stmt->execute();
		return $stmt;
	}
	//Get category name
	function getMainCategoryName()
	{
		echo "<p>Inside getMainCategoryName</p>";
				// insert query
		$query = "SELECT * FROM main_categoty";
        $stmt = $this->conn->prepare($query); 		
		$stmt->bindParam(':CATEGORY_NAME', $this->CATEGORY_NAME);
		$stmt->execute();
		/* $result=$stmt->fetchAll(PDO::FETCH_ASSOC);
		
		//print_r($result);
		
		foreach ($result as $row)
		{
			//print $row->CATEGORY_NAME;
			//extract($row);
			//printf("$row->CATEGORY_NAME");
			print_r($row['CATEGORY_NAME'].PHP_EOL);
			//printf("\n");
			
		} */
		return $stmt;
	}
	
	
	// create new category record
	function createSubCategory()
	{
			
		echo "<p>Inside craetw createSubCategory() </p>";
		// to get time stamp for 'created' field
		$this->CREATEDDATE=date('Y-m-d H:i:s');
		
		$this->CATEGORY_ID=$this->getMainCategoryId($this->CATEGORY_NAME);
		//this->category_id="mc_"+$i;
		
				// insert query
		$query = "INSERT INTO " . $this->table_name . "
            SET
			CATEGORY_ID =:CATEGORY_ID,
			SUBCATEGORY_NAME = :SUBCATEGORY_NAME,
			CREATEDDATE = :CREATEDDATE";
 		// prepare the query
		$stmt = $this->conn->prepare($query);
		
		$this->CATEGORY_NAME=htmlspecialchars(strip_tags($this->SUBCATEGORY_NAME));
		$stmt->bindParam(':CATEGORY_ID', $this->CATEGORY_ID);
		$stmt->bindParam(':SUBCATEGORY_NAME', $this->SUBCATEGORY_NAME);
		$stmt->bindParam(':CREATEDDATE', $this->CREATEDDATE);
		//$stmt->bindParam(':CATEGORY_NAME', $this->CATEGORY_NAME);
		
		
		if($stmt->execute())
		{
			return true;
		}
		else
		{
			$this->showError($stmt);
			return false;
		}
	}
	
	// used for paging users
	public function countAll()
	{
 
		// query to select all user records
		$query = "SELECT SUBCATEGORY_ID FROM " . $this->table_name . "";
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		// execute query
		$stmt->execute();
		// get number of rows
		$num = $stmt->rowCount();
		// return row count
		return $num;
	}
	
		// read all user records
	function readAllsubCategory($from_record_num, $records_per_page)
	{
		// query to read all user records, with limit clause for pagination
		$query = "SELECT
                SUBCATEGORY_ID,
				SUBCATEGORY_NAME
            FROM " . $this->table_name . "
            ORDER BY SUBCATEGORY_ID DESC
            LIMIT ?, ?";
 
		// prepare query statement
		$stmt = $this->conn->prepare( $query );
		// bind limit clause variables
		$stmt->bindParam(1, $from_record_num, PDO::PARAM_INT);
		$stmt->bindParam(2, $records_per_page, PDO::PARAM_INT);
 
		// execute query
		$stmt->execute();
		// return values
		return $stmt;
	}
}
	

?>